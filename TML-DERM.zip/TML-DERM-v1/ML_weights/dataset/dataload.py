import numpy as np
#import matplotlib.pyplot as plt
import tensorflow as tf
import scipy.io as sio
from sklearn import preprocessing
import random


class dataset(object):
    def __init__(self, fold, K_shots,  data_name, ensembled_num):
        # K for meta train, and another K for meta val
        self.ensembled_num = ensembled_num
        self.fold = fold
        
        if data_name == 'breast_cancer':
            self.dim_input = 71
            self.dim_output = 1
            self.name = 'breast_cancer'


            self._K = K_shots*2

            self.data_path = 'dataset/MG_data.mat'
            self.fold_path = 'dataset/MG5fold.mat'
            
        elif data_name == 'child_singleside':
            self.dim_input = 593
            self.dim_output = 1
            self.fold = fold
            self.name = 'child_singleside'
            
            self._K = K_shots*2
            
            self.data_path = 'dataset/data/data.mat' 
            
        elif data_name == 'cs':
            self.dim_input = 210
            self.dim_output = 2
            self.name = 'cs'


            self._K = K_shots * 2

            self.data_path = 'dataset/CS_data.mat'
            self.fold_path = 'dataset/CS5fold_han.mat'

        def __load_data__():

            if self.name == 'breast_cancer':
                mg_data = sio.loadmat(self.data_path)
                fold_index = sio.loadmat(self.fold_path)
                bus_raw = np.array(mg_data['BUS'])
                label = np.array(mg_data['label'])
                fold_index = np.array(fold_index['indice'])
                
            elif self.name == 'cs':
                mg_data = sio.loadmat(self.data_path)
                fold_index = sio.loadmat(self.fold_path)
                bus_raw = np.array(mg_data['dateus'])
                label = np.array(mg_data['label'])
                fold_index = np.array(fold_index['indice'])
                
            elif self.name == 'child_singleside':
                tmp_data = sio.loadmat(self.data_path)
                mg_data = tmp_data['data']
                bus_raw = np.array(mg_data['data'][0,0]).T # instance x dim: 758 x 593
                label = np.array(mg_data['labels'][0,0])
                fold_index = np.array(mg_data['fold'][0,0])

            label = label
            fold_index = fold_index
            

            mg_scaler = preprocessing.StandardScaler()  # StandardScaler  
            bus = mg_scaler.fit_transform(bus_raw) # 264 x 71


            fold_index = np.squeeze(fold_index)
            # 5-fold CV
            index_test = np.where(np.array(fold_index) == self.fold)
            self.train_BUS = np.delete(bus, index_test, axis=0)

            train_label = np.delete(label, index_test, axis=0)
            train_label = np.reshape(train_label, (-1,1))
            
            
            self.train_label  = train_label # 212 x 1


            self.test_BUS = bus[index_test]
            

            test_label = label[index_test]
            test_label = np.reshape(test_label, (-1,1))

            self.test_label = test_label # 52 x 1
            

        __load_data__()
        
        self.num_samples = len(self.train_label)
        self.num_test_sample = len(self.test_label)
        

    def get_batch(self, batch_size):
        all_batch_features_bus, all_batch_labels = [], []
        for i in range(batch_size):
            sampled_indice = random.sample(range(0, self.num_samples), self._K)
            labels = self.train_label[sampled_indice]
            features_bus = self.train_BUS[sampled_indice]
            all_batch_features_bus.append(features_bus)

            all_batch_labels.append(labels)
        all_batch_features = np.array(all_batch_features_bus)
        all_batch_labels = np.array(all_batch_labels)


        return all_batch_features, all_batch_labels

    #load testing data
    def get_batch_t(self, batch_size):
        all_batch_features_bus, all_batch_labels = [], []
        for i in range(batch_size): 
            sampled_indice = list(range(0, self.num_test_sample)) * 2
            labels = self.test_label[sampled_indice]
            features_bus = self.test_BUS[sampled_indice]
            all_batch_features_bus.append(features_bus)
            all_batch_labels.append(labels)
            
        
        all_batch_features = np.array(all_batch_features_bus)
        all_batch_labels = np.array(all_batch_labels)


        return all_batch_features, all_batch_labels


