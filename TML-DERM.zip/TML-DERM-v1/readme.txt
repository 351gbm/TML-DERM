
Prerequisites:
- Python 3.6
- Tensorflow 1.9
- [NumPy](http://www.numpy.org/) 1.13.3
- tqdm 4.19.4
- [colorlog](https://github.com/borntyping/python-colorlog) 3.1.0

Usage:
 training  python main.py --is_train
 testing python main.py --restore_dir PATH_TO_CHECKPOINT


Nothing: 
ML_weights learns the initializaion parameters of DERM. It needs to be conducted first. 




